#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    int check1, check2;
    for(i = 0; i < 100; i++){
        check1 = i % 3;
        check2 = i % 7;
        if(check1 == 0 && check2 == 0)
            printf("Fire and Ice\n");
        else if(check1 == 0 && check2 != 0)
            printf("Fire\n");
        else if(check1 != 0 && check2 == 0)
            printf("Ice\n");
        else
            printf("%d\n", i);
    }
    return(0);
}
