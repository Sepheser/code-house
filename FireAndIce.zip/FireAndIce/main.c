#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Loop Value
    int i;

    //Variables to use to check if the current number is divisible by 3 or 7.
    int check1, check2;

    //Loop to check all 100 numbers.
    for(i = 1; i <= 100; i++){
        //First check value, is it  evenly divisable by 3.
        check1 = i % 3;
        //Second check value, is it  evenly divisable by 7.
        check2 = i % 7;
        //Is it divisable by both.
        if(check1 == 0 && check2 == 0)
            printf("Fire and Ice\n");
        //Is is only divisable by 3.
        else if(check1 == 0 && check2 != 0)
            printf("Fire\n");
        //Is it only divisable by 7.
        else if(check1 != 0 && check2 == 0)
            printf("Ice\n");
        //If its not divisable by either.
        else
            printf("%d\n", i);
    }
    return(0);
}
