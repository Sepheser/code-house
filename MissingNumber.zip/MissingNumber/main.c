#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Defined values to make future editing easier.
#define StringSize 150
#define Size 25
#define arrays 5
#define tempSize 5

int main()
{

    char string[StringSize] = "";                           //Array to hole the initial string that the uer enters.
    char temp[tempSize] = "";                               //Hold the individual values to be switch to integers.
    int array[Size] = {0};                                  //The array to hole the integer values.
    int count, number, missing, high, element, check;       //Various variables to use for compareisons and holding crucial elements.
    int arrayCount = 1;                                     //To keep track of how many arrays have been run.
    int intPlace = 0;                                       //For use with the integer array.
    int charPlace = 0;                                      //For use with the string array.
    int tempPlace = 0;                                      //for use with the temp array.
    int answer = 0;                                         //Variable used to check if hte missing number has been found.

    //Loop to allow the correct number of arrays to be run.
    while(arrayCount <= arrays){

        //Re-zeros the array.
        for(count = 0; count < Size; count++){
            array[count] = 0;
        }

        //Resets intPlace and high for the next array.
        intPlace = 0;
        high = 0;

        //Ask the user for the array and hten scans it in to the string array.
        printf("Please enter the first set of numbers: ");
        scanf("%s", string);

        //This loop takes hte string array and converts it to an integer array.
        for(charPlace = 0; charPlace < StringSize; charPlace++){
            //Runs every time it reaches a comma and places the elements it loaded into temp into array.
            if(string[charPlace] == ','){
                number = atoi(temp);
                array[intPlace] = number;
                intPlace++;
                //Calculating high.
                if(number > high)
                    high = number;
                tempPlace = 0;
            }
            //Runs on the final element to get the last value since there is no final comma.
            else if(string[charPlace] == '\0'){
                number = atoi(temp);
                array[intPlace] = number;
                //Calculating high.
                if(number > high)
                    high = number;
                tempPlace = 0;
                //forces the loop to end.
                charPlace = StringSize;
            }
            //collects the numbers from string into temp to be converted to integers.
            else{
                temp[tempPlace] = string[charPlace];
                tempPlace++;
            }
        }
        //Loop to find the missing number, it excludes are array elements tha are equal to 0.
        for(count = 0; count < Size; count++){
            //If statement excludes the highest value, because it would have no value grater then it.
            if(array[count] != high){
                if(array[count] != 0){
                    answer = 1;
                    check = array[count] + 1;
                    for(element = 0; element < Size; element++){
                        if(array[element] != 0){
                            if(check == array[element]){
                                answer = 0;
                            }
                        }
                    }
                }
            }
            //Checks to see if an element one higher then the previous one checked exists.
            if(answer == 1 && array[count] > 0)
                missing = array[count] + 1;
        }
        //prints the missing number.
        printf("The missing number is: %d\n", missing);

        //Increments arrayCount, showing that an array has been run.
        arrayCount++;
    }
    return 0;
}
