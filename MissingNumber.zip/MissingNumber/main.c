#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define StringSize 150
#define Size 25
#define arrays 5
#define tempSize 5

int main()
{
    char string[StringSize] = "";
    char temp[tempSize] = "";
    int array[Size] = {0};
    int count, number, missing, high, element, check;
    int arrayCount = 1;
    int intPlace = 0;
    int charPlace = 0;
    int tempPlace = 0;
    int answer = 0;

    while(arrayCount <= arrays){

        for(count = 0; count < Size; count++){
            array[count] = 0;
        }

        intPlace = 0;
        high = 0;

        printf("Please enter the first set of numbers: ");
        scanf("%s", string);

        for(charPlace = 0; charPlace < StringSize; charPlace++){
            if(string[charPlace] == ','){
                number = atoi(temp);
                array[intPlace] = number;
                intPlace++;
                if(number > high)
                    high = number;
                tempPlace = 0;
            }
            else if(string[charPlace] == '\0'){
                number = atoi(temp);
                array[intPlace] = number;
                if(number > high)
                    high = number;
                tempPlace = 0;
                charPlace = StringSize;
            }
            else{
                temp[tempPlace] = string[charPlace];
                tempPlace++;
            }
        }
        for(count = 0; count < Size; count++){
            if(array[count] != high){
                if(array[count] != 0){
                    answer = 1;
                    check = array[count] + 1;
                    for(element = 0; element < Size; element++){
                        if(array[element] != 0){
                            if(check == array[element]){
                                answer = 0;
                            }
                        }
                    }
                }
            }
            if(answer == 1 && array[count] > 0)
                missing = array[count] + 1;
        }
        printf("The missing number is: %d\n", missing);

        arrayCount++;
    }
    return 0;
}
